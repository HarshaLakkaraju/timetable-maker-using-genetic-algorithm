from django.apps import AppConfig


class TtgenConfig(AppConfig):
    name = 'ttgen'
